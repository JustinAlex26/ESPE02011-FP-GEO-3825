"Justin Vasconez until workshops " 
